﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlaisePascal.SmartHouse.Domain.Lamps
{
    public enum LampColor
    {
        White,
        WarmWhite,
        CoolWhite,
        Red,
        Green,
        Blue,
        Yellow,
        Purple
    }
}
